# ✅ Ejemplo SEGURO — Capítulo 9 (Micro Front-End)

## Descripción
Este proyecto es una versión SEGURA del micro front-end para demostrar buenas prácticas:
- Validación de entrada.
- Hash de contraseñas.
- Tokens CSRF (`AntiForgeryToken`).
- No exponer datos sensibles.

## Ejecución
```bash
dotnet restore
dotnet build
dotnet run
```

## Rutas Seguras
- /Account/Register
- /Account/Login
- /Account/Profile
