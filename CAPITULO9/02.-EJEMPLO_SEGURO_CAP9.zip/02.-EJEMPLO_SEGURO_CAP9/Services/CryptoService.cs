using System;
using System.Security.Cryptography;
using System.Text;

namespace EjemploSeguroCapitulo9.Services
{
    public class CryptoService
    {
        public (string hash, string salt) HashPassword(string password)
        {
            byte[] saltBytes = RandomNumberGenerator.GetBytes(16);
            using var pbkdf2 = new Rfc2898DeriveBytes(password, saltBytes, 100_000, HashAlgorithmName.SHA256);
            string hash = Convert.ToBase64String(pbkdf2.GetBytes(32));
            return (hash, Convert.ToBase64String(saltBytes));
        }

        public bool VerifyPassword(string password, string salt, string hashToCompare)
        {
            byte[] saltBytes = Convert.FromBase64String(salt);
            using var pbkdf2 = new Rfc2898DeriveBytes(password, saltBytes, 100_000, HashAlgorithmName.SHA256);
            string hash = Convert.ToBase64String(pbkdf2.GetBytes(32));
            return hash == hashToCompare;
        }
    }
}
