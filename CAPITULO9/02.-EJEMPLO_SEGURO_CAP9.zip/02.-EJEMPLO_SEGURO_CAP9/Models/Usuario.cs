
namespace EjemploSeguroCapitulo9.Models
{
    public class Usuario
    {
        public string Nombre { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}
