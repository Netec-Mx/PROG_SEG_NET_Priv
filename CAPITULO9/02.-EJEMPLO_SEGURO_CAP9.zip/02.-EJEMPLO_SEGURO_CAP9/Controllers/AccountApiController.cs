// ================================================================
//   AccountApiController.cs — Controlador REST (Versión SEGURA)
// ================================================================
// Expone endpoints JSON para registro, login y perfil.
// - Usa hashing de contraseña con salt vía CryptoService.
// - Valida credenciales en memoria.
// - Usa Session segura para persistir login temporal.
// ================================================================

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http; // ✅ IMPORTANTE para usar SessionExtensions
using EjemploSeguroCapitulo9.Models;
using EjemploSeguroCapitulo9.Services;
using System.Collections.Generic;
using System.Linq;

namespace EjemploSeguroCapitulo9.Controllers
{
    [ApiController]
    [Route("api/account")]
    public class AccountApiController : ControllerBase
    {
        private readonly CryptoService _crypto;
        private static List<Usuario> _usuarios = new();

        public AccountApiController(CryptoService crypto)
        {
            _crypto = crypto;
        }

        /// <summary>
        /// POST: api/account/register
        /// Registra un usuario aplicando hash + salt.
        /// </summary>
        [HttpPost("register")]
        public IActionResult Register([FromBody] Usuario input)
        {
            var (hash, salt) = _crypto.HashPassword(input.Password);
            _usuarios.Add(new Usuario
            {
                Nombre = input.Nombre,
                Password = $"{hash}:{salt}"
            });
            return Ok(new { message = "Usuario registrado de forma segura (API REST)." });
        }

        /// <summary>
        /// POST: api/account/login
        /// Verifica credenciales usando hash + salt.
        /// Crea sesión usando Session.
        /// </summary>
        [HttpPost("login")]
        public IActionResult Login([FromBody] Usuario input)
        {
            var user = _usuarios.FirstOrDefault(u => u.Nombre == input.Nombre);
            if (user == null)
                return Unauthorized(new { error = "Usuario no existe." });

            var parts = user.Password.Split(':');
            if (parts.Length != 2)
                return Unauthorized(new { error = "Formato de credencial inválido." });

            string hashStored = parts[0];
            string saltStored = parts[1];

            bool ok = _crypto.VerifyPassword(input.Password, saltStored, hashStored);
            if (!ok)
                return Unauthorized(new { error = "Contraseña incorrecta." });

            // ✅ Guarda el username en Session usando extensiones correctas
            HttpContext.Session.SetString("ApiUsername", user.Nombre);

            return Ok(new { message = $"Login OK para {user.Nombre}" });
        }

        /// <summary>
        /// GET: api/account/profile
        /// Devuelve perfil del usuario logueado (sin exponer contraseña).
        /// </summary>
        [HttpGet("profile")]
        public IActionResult Profile()
        {
            var username = HttpContext.Session.GetString("ApiUsername");
            if (string.IsNullOrEmpty(username))
                return Unauthorized(new { error = "No autenticado o sesión expirada." });

            return Ok(new
            {
                username = username,
                note = "Este perfil NO expone la contraseña. (API REST segura)"
            });
        }
    }
}