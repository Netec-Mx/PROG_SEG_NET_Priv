// ================================================================
//   AccountController.cs — Versión SEGURA DEFINITIVA (WEB MVC)
// ================================================================
// Controlador MVC para registro, login y perfil.
// - Recibe modelo Usuario para binding correcto.
// - Usa CryptoService para hash y validación.
// - Guarda usuario autenticado en Session.
// ================================================================

using Microsoft.AspNetCore.Mvc;
using EjemploSeguroCapitulo9.Models;
using EjemploSeguroCapitulo9.Services;
using System.Collections.Generic; // Para List<>
using System.Linq; // Para FirstOrDefault
using Microsoft.AspNetCore.Http; // Para Session

namespace EjemploSeguroCapitulo9.Controllers
{
    public class AccountController : Controller
    {
        private readonly CryptoService _crypto;
        private static List<Usuario> _usuarios = new();

        public AccountController(CryptoService crypto)
        {
            _crypto = crypto;
        }

        // --------------------------------------------
        // GET: /Account/Register
        // Muestra formulario de registro.
        // --------------------------------------------
        [HttpGet]
        public IActionResult Register() => View();

        // --------------------------------------------
        // POST: /Account/Register
        // Registra usuario con hash y salt.
        // --------------------------------------------
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(Usuario usuario)
        {
            if (string.IsNullOrWhiteSpace(usuario.Nombre) || string.IsNullOrWhiteSpace(usuario.Password))
                return BadRequest("Nombre y contraseña son requeridos.");

            var (hash, salt) = _crypto.HashPassword(usuario.Password);

            _usuarios.Add(new Usuario
            {
                Nombre = usuario.Nombre,
                Password = $"{hash}:{salt}"
            });

            // Guardar usuario en sesión para mostrarlo en Profile
            HttpContext.Session.SetString("WebUsername", usuario.Nombre);

            return RedirectToAction("Profile");
        }

        // --------------------------------------------
        // GET: /Account/Login
        // Muestra formulario de login.
        // --------------------------------------------
        [HttpGet]
        public IActionResult Login() => View();

        // --------------------------------------------
        // POST: /Account/Login
        // Verifica credenciales y guarda sesión.
        // --------------------------------------------
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(Usuario usuario)
        {
            if (string.IsNullOrWhiteSpace(usuario.Nombre) || string.IsNullOrWhiteSpace(usuario.Password))
                return BadRequest("Nombre y contraseña son requeridos.");

            var user = _usuarios.FirstOrDefault(u => u.Nombre == usuario.Nombre);
            if (user == null)
                return Unauthorized("Usuario no encontrado.");

            var parts = user.Password.Split(':');
            if (parts.Length != 2)
                return Unauthorized("Credenciales corruptas.");

            string hash = parts[0];
            string salt = parts[1];

            bool ok = _crypto.VerifyPassword(usuario.Password, salt, hash);
            if (!ok)
                return Unauthorized("Contraseña incorrecta.");

            // Guardar usuario en sesión para mostrarlo en Profile
            HttpContext.Session.SetString("WebUsername", user.Nombre);

            return RedirectToAction("Profile");
        }

        // --------------------------------------------
        // GET: /Account/Profile
        // Muestra perfil con usuario desde sesión.
        // --------------------------------------------
        [HttpGet]
        public IActionResult Profile()
        {
            var username = HttpContext.Session.GetString("WebUsername");
            ViewBag.Username = username ?? "Invitado";
            return View();
        }
    }
}